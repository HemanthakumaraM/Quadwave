﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using QuadWaveAPI.DataObject;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Profiles
{
    public class CustProfile:Profile
    {
        public CustProfile()
        {
            CreateMap<CustomerData, ReadData>();
            CreateMap<CreateData, CustomerData>();
            CreateMap<UpdateData, CustomerData>();
            CreateMap<DeleteData, CustomerData>();

            CreateMap<CustomerAddress, AddressRead>();
            CreateMap<AddressCreate, CustomerAddress>();
            CreateMap<AddressUpdate, CustomerAddress>();
            CreateMap<AddressDelete, CustomerAddress>();
        }

    }
}
