﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadWaveAPI.Migrations
{
    public partial class addcustomerData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into customerData values('Hemanthakumara','M','03/01/2022 12:11:10:0')");
            migrationBuilder.Sql("insert into customerData values('Shet','Ru','02/02/2022 10:10:10:0')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
