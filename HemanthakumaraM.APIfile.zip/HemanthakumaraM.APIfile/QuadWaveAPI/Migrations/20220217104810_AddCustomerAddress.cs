﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadWaveAPI.Migrations
{
    public partial class AddCustomerAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into customerAddress values('1','Mysore','Hosaramanahalli','India')");
            migrationBuilder.Sql("insert into customerAddress values('2','Murudeshwara','Neartemple','India')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
