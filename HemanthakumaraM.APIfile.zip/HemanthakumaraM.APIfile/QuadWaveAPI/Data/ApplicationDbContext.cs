﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> opt) : base(opt)
        {

        }
            public DbSet<CustomerData> customerData { set; get; }
        public DbSet<CustomerAddress> customerAddress { set; get; }
    }
}
