﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Data
{
    public class info:Interface
    {
        private readonly ApplicationDbContext _context;

        public info(ApplicationDbContext context)
        {
            _context = context;
        }
        public CustomerData GetCustomerData(int Id)
        {
            var customer = _context.customerData.SingleOrDefault(m => m.Id == Id);
            return customer;
        }
        public List<CustomerData> GetCustomer()
        {
            var customer = _context.customerData.ToList();
            return customer;
        }
        public CustomerData CreateDetails(CustomerData newCust)
        {
            _context.customerData.Add(newCust);
            _context.SaveChanges();
            return newCust;       
        }
        public void UpdateDetails(CustomerData e)
        {
            _context.SaveChanges();
        }
        public void DeleteDetails(CustomerData e)
        {
            _context.Remove(e);
            _context.SaveChanges();
        }

        public void Updatedetails(CustomerData e)
        {
            _context.SaveChanges();
        }

      //CustomerAddress
        
        public CustomerAddress GetCustomerAddress(int Id)
        {
            var custo = _context.customerAddress.SingleOrDefault(m => m.Id == Id);
            return custo;
        }
        public List<CustomerAddress> GetCustomerAdd()
        {
            var custom = _context.customerAddress.ToList();
            return custom;
        }
        public CustomerAddress CreateAddress(CustomerAddress newCust)
        {
            _context.customerAddress.Add(newCust);
            _context.SaveChanges();
            return newCust;
        }
        public void UpdateAddress(CustomerAddress e)
        {
            _context.SaveChanges();
        }
        public void DeleteAddress(CustomerAddress e)
        {
            _context.Remove(e);
            _context.SaveChanges();
        }
    }
}


