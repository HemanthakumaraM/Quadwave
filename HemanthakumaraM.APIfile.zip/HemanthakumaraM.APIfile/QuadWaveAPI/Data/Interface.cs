﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Data
{
   public interface Interface
    {
        public CustomerData GetCustomerData(int Id);
        public List<CustomerData> GetCustomer();
        public CustomerData CreateDetails(CustomerData newCust);
        public void Updatedetails(CustomerData e);
        public void DeleteDetails(CustomerData e);


        //CustomerAddress
        public CustomerAddress GetCustomerAddress(int Id);
        public List<CustomerAddress> GetCustomerAdd();
        public CustomerAddress CreateAddress(CustomerAddress newCust);
        public void UpdateAddress(CustomerAddress e);
        public void DeleteAddress(CustomerAddress e);
    }
}


