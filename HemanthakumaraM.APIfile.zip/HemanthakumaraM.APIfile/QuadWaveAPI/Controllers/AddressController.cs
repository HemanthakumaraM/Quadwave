﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadWaveAPI.Data;
using QuadWaveAPI.DataObject;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class AddressController : Controller
    {
        private Interface _inf;
        private IMapper _mapper;

        public AddressController(Interface inf, IMapper mapper)
        {
            _inf = inf;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public ActionResult<AddressRead> GetCustomerAddress(int id)
        {
            var application = _inf.GetCustomerAddress(id);
            return Ok(_mapper.Map<AddressRead>(application));
        }
        [HttpGet]
        public ActionResult<IEnumerable<AddressRead>> GetCustomerAdd()
        {
            var appln = _inf.GetCustomerAdd();
            return Ok(_mapper.Map<IEnumerable<AddressRead>>(appln));
        }
        [HttpPost]
        public ActionResult<AddressRead> CreateAddress(AddressCreate addressCreate)
        {
            if (addressCreate != null)
            {
                var newCust = _mapper.Map<CustomerAddress>(addressCreate);
                _inf.CreateAddress(newCust);
                return Ok(addressCreate);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{id}")]
        public ActionResult UpdateAddress(AddressUpdate addressUpdate, int id)
        {
            var custUp = _inf.GetCustomerAddress(id);
            if (custUp != null)
            {
                _mapper.Map(addressUpdate, custUp);
                _inf.UpdateAddress(custUp);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete]
        public ActionResult DeleteAddress(AddressDelete addressDelete, int id)
        {
            var cust = _inf.GetCustomerAddress(id);
            _mapper.Map(addressDelete,cust);
            _inf.DeleteAddress(cust);
            return Ok();
        }
    }
}
