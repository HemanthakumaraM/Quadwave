﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadWaveAPI.Data;
using QuadWaveAPI.DataObject;
using QuadWaveAPI.Model;

namespace QuadWaveAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class CustomerController : Controller
    {
        private readonly Interface _inf;
        private readonly IMapper _mapper;

        public CustomerController(Interface inf,IMapper mapper)
        {
            _inf = inf;
            _mapper = mapper;
        }
    [HttpGet("{id}")]
    public ActionResult<ReadData> GetCustomerDataById(int id)
        {
        var application = _inf.GetCustomerData(id);
        return Ok(_mapper.Map<ReadData>(application));
        }
        [HttpGet]
        public ActionResult<IEnumerable<ReadData>> GetCustomer()
        {
            var appln = _inf.GetCustomer();
            return Ok(_mapper.Map<IEnumerable<ReadData>>(appln));
        }
        [HttpPost]
        public ActionResult<ReadData> CreateDetails(CreateData createData)
        {
            if(createData!=null)
            {
                var newCust = _mapper.Map<CustomerData>(createData);
                _inf.CreateDetails(newCust);
                return Ok(createData);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{id}")]
        public ActionResult Updatedetails(UpdateData updateData,int id)
        {
            var custUp = _inf.GetCustomerData(id);
            if (custUp != null)
            {
                _mapper.Map(updateData, custUp);
                _inf.Updatedetails(custUp);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete]
        public ActionResult DeleteDetails(DeleteData deleteData,int id)
        {
            var cust = _inf.GetCustomerData(id);
            _mapper.Map(deleteData, cust);
            _inf.DeleteDetails(cust);
            return Ok();
        }

        //CustomerAddresss

    }
}
